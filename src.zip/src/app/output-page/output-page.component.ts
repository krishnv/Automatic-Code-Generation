import { Component, Input, EventEmitter, Output,OnInit } from '@angular/core';
import { InputPageComponent } from "../input-page/input-page.component";
import { RecieveDataService } from '../services/recieve-data.service';

@Component({
  selector: 'app-output-page',
  templateUrl: './output-page.component.html',
  styleUrls: ['./output-page.component.css']
})
export class OutputPageComponent implements OnInit {
  

  Language='';
  data='java code';
  codeloc='';
  constructor(private outputService:RecieveDataService ) { }

  ngOnInit(): void {
    this.Language=sessionStorage.getItem('Language');
    // console.log("Output Component"+JSON.stringify(this.output));
    this.outputService.currentApprovalStageMessage.subscribe(msg => this.data = msg);
    console.log(this.data)
    this.codeloc=this.data["sourceFile"]
  }
  
  sourceFileDownload(){
    this.downloadFile(this.data["sourceFile"],'main')
  }

  outputFileDownload(){
    this.downloadFile(this.data["outputFile"],'outputFile')
  }

  referenceUrlDownload(){
    this.downloadFile(this.data["ReferenceFile"],'referenceUrl')
  }
  downloadFile(data: any, name: string) {
    // const blob = new Blob([data], { type: 'text/csv' });
    // const url= window.URL.createObjectURL(blob);
    // window.open(url);
    let type='py';
    if(this.Language=='Java'){
      type= 'java'
    }
    var blob = new Blob([data], { type: type });
    var url = window.URL.createObjectURL(blob);
    var anchor = document.createElement("a");
    if(name=='main'){
    anchor.download = name+'.'+type;}
    else{
      anchor.download = name+'.txt';
    }
    anchor.href = url;
    anchor.click();
  }

}
