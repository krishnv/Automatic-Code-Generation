import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SendDataService {
  serverAddress= "http://localhost:5000"
  constructor(
    private http:HttpClient
  ) { }

  send_post_request(data){
    return this.http.post(
      this.serverAddress,JSON.stringify(data)
    )
  }
}
