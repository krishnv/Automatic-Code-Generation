import { Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import { Router } from '@angular/router';
import { SendDataService } from '../services/send-data.service';
import { RecieveDataService } from "../services/recieve-data.service";


@Component({
  selector: 'app-input-page',
  templateUrl: './input-page.component.html',
  styleUrls: ['./input-page.component.css']
})
export class InputPageComponent implements OnInit {

@ViewChild('fileUpload1', {static: false}) fileUpload1:ElementRef;

  lengthValidation=true;
  inputQuery='';
  inputQueryWords:number;
  myRadio: string = 'Python';
  fileToUpload: File | null = null;
  fileBoolean=false;
  fileSelected=false;
  response:any;
  currentInput;
  filename='';
  fileData='';

  constructor(private router: Router, private service:SendDataService, private outputService:RecieveDataService) { }

  ngOnInit(): void {
    
  }

onFileSelected($event) {
  this.fileSelected=true;
    console.log("Inside handleFileInput");
    console.log(this.currentInput);
    this.filename= this.currentInput.split('\\').pop().split('/').pop();
    this.filename="C:/InputFiles/"+this.filename;
    console.log(this.filename)
  }

  WordCount() {
    console.log(this.lengthValidation);
    this.inputQueryWords= this.inputQuery.split(' ')
           .filter(function(n) { return n != '' })
           .length;
    if(this.inputQueryWords<3){
      this.lengthValidation=false;
    }else{
      this.lengthValidation=true; 
    }

}
  OnSubmit(){
    let fileReader = new FileReader();
    if(this.fileBoolean && this.fileSelected && this.fileUpload1.nativeElement.files[0] !=null){
      fileReader.readAsText(this.fileUpload1.nativeElement.files[0]);
    }

    fileReader.onload=(e)=>{
      if(<string> fileReader.result != null){
        this.fileData=<string> fileReader.result;
        console.log("filedata is "+this.fileData)
      }
    }



    this.WordCount();
    console.log(this.inputQuery);
    if(this.lengthValidation){
    sessionStorage.setItem("Language" ,this.myRadio );
    const myData = {  
      inputQuery: this.inputQuery,  
      Language: this.myRadio,  
      fileData:  this.fileData
    };  
    this.delay(1500).then(any=>{
  if(this.fileSelected == (this.fileData!='')){
  this.service.send_post_request(myData).subscribe(data => {
    this.response = data
    console.log(this.response)
    this.outputService.updateApprovalMessage(this.response)
     this.router.navigate(['./output']);
  })
}
});

}
  }
  async delay(ms: number) {
    await new Promise<void>(resolve => setTimeout(()=>resolve(), ms)).then(()=>console.log("fired"));
}
  
  
}
